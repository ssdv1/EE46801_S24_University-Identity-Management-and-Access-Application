# University-Identity-Management-and-Access-Application
University Identity Management and Access Application 

--------------------------
Framework Commit
UML is the project that consists of all the major code including the templates and database connection
MyProject is just a placeholder that I have used to create a virtual server for the Django framework that roots the webBrowser for now the Default URl for the browser is the System IP along with its port number but that can be changed to a certain URl urls.py 
